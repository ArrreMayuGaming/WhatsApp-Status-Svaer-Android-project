package com.example.statussaverpro.Adapters;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.statussaverpro.Fragments.ImageFragment;
import com.example.statussaverpro.Fragments.VideoFragment;

public class PagerAdapter extends FragmentPagerAdapter {


    private ImageFragment If;
    private VideoFragment Vf;


    public PagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
        If=new ImageFragment();
        Vf=new VideoFragment();
    }

    @NonNull
    @Override
    public Fragment getItem(int i) {

        if(i==0)
        {
            return If;
        }
        else
        {
            return Vf;
        }
    }

    @Nullable
    @Override
    public CharSequence getPageTitle( int position){
        if (position==0)
        {
            return "Images";

        }
        else
        {
            return "Videos";
        }
    }

    @Override
    public int getCount() {
        return 2;
    }
}
