package com.example.statussaverpro.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.statussaverpro.Fragments.ImageFragment;
import com.example.statussaverpro.Fragments.VideoFragment;
import com.example.statussaverpro.Models.StatusModel;
import com.example.statussaverpro.R;

import java.io.IOException;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    //private final List<StatusModel> videoList;
    public   List<StatusModel> videoList ;
    Context context;
    VideoFragment imageFragment;

    public VideoAdapter(Context context,List<StatusModel> imageList,VideoFragment imageFragment)
    {
        this.context=context;
       this.videoList= videoList;
        this.imageFragment=imageFragment;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.status_item,viewGroup,false);
        return new VideoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder videoViewHolder, int i) {
        StatusModel statusModel = videoList.get(i);
        videoViewHolder.ivThumbnailimageView.setImageBitmap(statusModel.getThubnail());
    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }

    public class VideoViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.ivThumbnail)
        ImageView ivThumbnailimageView;
        @BindView(R.id.ibSaveToGallery)
        ImageButton imageDownloadButton;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);

            imageDownloadButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    StatusModel statusModel=videoList.get(getAdapterPosition());

                    if(statusModel!=null)
                    {
                        try {
                            imageFragment.downloadImage(statusModel);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }


                }
            });

        }
    }
}
